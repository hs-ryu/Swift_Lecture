//
//  Model.swift
//  finalpjt
//
//  Created by ryu hyunsun on 2023/09/19.
//

import SwiftUI

struct Model {
    let name: String
    let image: Image
    let description: String
}
